#include "sdk.h"

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/buffer.h>
//#include <sys/select.h>
//#include <socket.h>
//#include <netinet/in.h>
#include "Winsock.h" 
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <stdlib.h>
#include <stdio.h>
//#include <unistd.h>
#include <errno.h>


#pragma comment (lib, "libeay32.lib" ) 

#pragma comment (lib, "ssleay32.lib" ) 




    
#include <stdlib.h>   
#include <memory.h>

#define CERTF   "servercert.pem"
#define KEYF    "serverkey.der"


void main()
{

	printf("***********************************************\n");
	printf("#                 SSL server                  #\n");
	printf("***********************************************\n");
	int err;
	SOCKET listen_sd,sd;
	struct sockaddr_in sa_serv;
	struct sockaddr_in sa_cli;
	int client_len;
	SSL_CTX* ctx;
	SSL*     ssl;
	X509*    client_cert;
	u_short IpPortnum=5000;
	char*    str;
	char     buf [10*1024];
	char IpPort[10];
	SSL_METHOD *meth;


	WORD wVersionRequested;
	WSADATA wsaData;
 
	wVersionRequested = MAKEWORD( 2, 2 );
 
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 ) {
	  /* Tell the user that we could not find a usable */
	  /* WinSock DLL.                                  */
	  return;
	 }
	if ( LOBYTE( wsaData.wVersion ) != 2 ||
			HIBYTE( wsaData.wVersion ) != 2 ) {
	  /* Tell the user that we could not find a usable */
	  /* WinSock DLL.                                  */
	  WSACleanup( );
	  return; 
	 }


  	SSL_load_error_strings();
  	SSLeay_add_ssl_algorithms();
	//����˿ں�
	printf("please input the port number:");
	if (fgets(IpPort,10,stdin)!=NULL)
	{	
		printf("IpPort:%s ",IpPort);
		if (!(IpPortnum = atoi(IpPort)))
		{	
			IpPortnum = 3456;
		}
	}
	else 
	{	
		IpPortnum = 3456;
	}
  	meth = (SSL_METHOD *)SSLv23_server_method();
  	ctx = SSL_CTX_new (meth);
  	if (!ctx) {
    	ERR_print_errors_fp(stderr);
    	exit(2);
  	}
  
  	SSL_CTX_set_verify(ctx,SSL_VERIFY_NONE,NULL);
  
 	if (SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM) <= 0) {
    	exit(3);
  	}
   	if (SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_ASN1) <= 0) {
    	exit(4);
  	}

  	if (!SSL_CTX_check_private_key(ctx)) {
    	fprintf(stderr,"Private key does not match the certificate public key\n");
    	exit(5);
  	}


  	listen_sd=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);   
  	memset (&sa_serv, '\0', sizeof(sa_serv));
  	sa_serv.sin_family      = PF_INET;
  	sa_serv.sin_addr.s_addr =htonl(INADDR_ANY);
  	sa_serv.sin_port        = htons(IpPortnum);          
	int opt=1;
	err=setsockopt(listen_sd,SOL_SOCKET,SO_REUSEADDR,(const char *)&opt,sizeof(opt));
	if(err<0)
	{
		fprintf(stderr,"setsockopt\n");
		exit(5);
	}
  	err = bind(listen_sd, (struct sockaddr*) &sa_serv,sizeof (sa_serv));                  
  	err = listen (listen_sd, 5);                   
  	while(1)
  	{
		client_len = sizeof(sa_cli);
		printf("waiting for connect....\n");
		sd = accept (listen_sd, (struct sockaddr*) &sa_cli, &client_len);
		if(sd==-1)
		{
			closesocket(sd);
			break;	
		}
		  //close (listen_sd);
		printf ("Connection from %s, port %d\n",inet_ntoa(sa_cli.sin_addr),IpPortnum);
		ssl = SSL_new (ctx); 
		if(ssl==NULL)
		{
			closesocket(sd);
			break;
			}                          
		SSL_set_fd (ssl, sd);
		//fprintf(stderr,"[%s]\n",SSL_state_string_long(ssl));
		err = SSL_accept (ssl);                        


		//fprintf(stderr,"[%s]\n",SSL_state_string_long(ssl));
		printf ("SSL connection using CIPHER is [%s]\n", SSL_get_cipher(ssl));


	    client_cert = SSL_get_peer_certificate (ssl);
	    if (client_cert != NULL) {
		printf ("Client certificate:\n");

		str = X509_NAME_oneline (X509_get_subject_name (client_cert), 0, 0);
		
		printf ("\t subject: %s\n", str);
		OPENSSL_free (str);

		str = X509_NAME_oneline (X509_get_issuer_name  (client_cert), 0, 0);
		printf ("\t issuer: %s\n", str);
		OPENSSL_free (str);



		X509_free (client_cert);
	  	} else
    		printf ("Client does not have certificate.\n");
	  	while(1)
		{
			memset(buf,0,sizeof(buf));
			err = SSL_read (ssl, buf, sizeof(buf));
			buf[err] = '\0';
			if(err>0)
			{
				printf ("Got %d chars\n", err);
				SSL_write (ssl, buf, err);
			}
			else
				break;
		}
		closesocket(sd);
	}
	closesocket(listen_sd);
  	SSL_free (ssl);
	SSL_CTX_free (ctx);
 	WSACleanup();

}
#ifndef _SDK_H_
#define _SDK_H_

//#include <sys/select.h>
//#include <sys/socket.h>
//#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
//#include <unistd.h>
#include <errno.h>



    
#include <stdlib.h>   
#include <memory.h>

#ifdef  __cplusplus
extern "C" {
#endif

#include <stddef.h>

#if !defined(NO_SYS_TYPES_H)
#include <sys/types.h>
#endif

#define SDK_MAX_REGSTRING   16 /* Max Registration String Size */ 
typedef unsigned char uint8_t;
typedef unsigned char uchar;
typedef unsigned short uint16_t;

typedef void *  SDK_HANDLE;
typedef unsigned int  OS_TIMES;
typedef struct socket_addr  SOCKET_ADDR;

typedef enum
{
  orvOK,
  orvUNKNOWNCMD,
  orvUNKNOWNSUBCMD,
  orvUNKNOWNDEVICENUM,
  orvUNKNOWNBUFFERADDR,
  orvUNKNOWNFLAGADDR,
  orvCMDUNSUPPORTED,
  orvSUBCMDUNSUPPORTED,
  orvMODEUNSUPPORTED,
  orvNOTENABLED,
  orvINVCONFIGURATION,
  orvDEVICETIMEOUT,
  orvBUFFEROVERFLOW,
  orvDEVICEBUSY,
  orvDEVICEUNAVAILABLE,
  orvDEVICEFAULT,
  orvDEVICENOTOPEN,
  orvDEVICEREWOUND,
  orvDEVICENOTCONFIGURED,
  orvDEVICEDISCONNECT,
  orvDEVICERESET,
  orvDEVICECLOSED,
  orvTIMERSUNAVAILABLE,
  orvTIMERNOTFOUND,
  orvINVTIMEINTERVAL,
  orvPROCESSINBADSTATE,
  orvPROCESSNOTFOUND,
  orvPARITYERROR,
  orvLRCERROR,
  orvDATAOVERRUN,
  orvINVDATA,
  orvINVHANDLE,
  orvINVSIZE,
  orvNAK,
  orvFRAMINGERROR,
  orvNODIALLINE,
  orvXMODEMCRCERROR,
  orvXMODEMLRCERROR,
  orvLINEBUSY,
  orvNOANSWER,
  orvPAPEROUT,
  orvOVERHEAT,
  orvDCDLOST,
  orvDMRECEIVED,
  orvSENDINGERROR,
  orvUNEXPECTEDERROR,
  orvPOLLINGLOSS,
  orvXMODEMTIMEOUT,
  orvLAPMINVFRAME,
  orvLAPMDINVSEQNUM,
  orvLAPMTIMEOUT,
  orvLAPMDMRECEIVED,
  orvLAPMDISCRECEIVED,
  orvLAPMFRMRRECEIVED,
  orvDEVICENOCARD,
  orvEFATERR,
  orvEMFILE,
  orvENOENT,
  orvNOACCESS,
  orvNOMEMORY,
  orvENEXT,
  orvENOMORE,
  orvTWOCARDSDETECTED,
  orvUNKNOWNERROR,
  orvMAXERRORS
}OS_RETURN_VALS;

typedef enum
{
	SSL_AUTH_NONE,
	SSL_AUTH_CLIENT,
	SSL_AUTH_CLIENT_FAIL 
}SSL_AUTH_OPT;

typedef enum
{
	HANDSHAKE_SSLv2, 
	HANDSHAKE_SSLv23, 
	HANDSHAKE_SSLv3, 
	HANDSHAKE_TLSv1
}SSL_HANDSHAKE_OPT;
typedef enum 
{ 
	SSL_IS_DISCONNECTED,
	SSL_CONNECTION_IN_PROGRESS, 
	SSL_IS_CONNECTED 
}SSL_CONNECTION_STATE; 

#define	SDK_NOWAIT O_NONBLOCK
#define	SDK_SUSPEND 1   //BLOCKING

typedef enum 
{ 
	FILE_DER,
	FILE_PEM
}SSL_FILE_FORMAT;

struct socket_addr
{
	unsigned int addr_type;
	unsigned int addr_len;
	uint8_t addr[45];
	uint16_t port; 

};

//int verify_callback_server(int ok,X509_STORE_CTX *ctx);
//int verify_callback(int preverify_ok,X509_STORE_CTX * x509_ctx);
//int SSL_CTX_use_PrivateKey_file_pass(SSL_CTX* ctx,char *filename,char *pass);
//void ShowCerts(SSL * ssl);
SDK_HANDLE SDK_OpenSSLSocket(int type,int auth_opt,int* cipher,int mempool);
OS_RETURN_VALS SDK_CloseSSLSocket(SDK_HANDLE handle);
OS_RETURN_VALS SDK_SSLConnect(SDK_HANDLE handle, SOCKET_ADDR *pServer, int timeout);
int SDK_GetSSLBlockingMode(void);
OS_RETURN_VALS SDK_SetSSLBlockingMode(int mode);
OS_RETURN_VALS SDK_SetSSLMode(SDK_HANDLE handle,int mode);
OS_RETURN_VALS SDK_SSLDisconnect(SDK_HANDLE handle); 
OS_RETURN_VALS SDK_LastSSLError(void);  
OS_RETURN_VALS SDK_SSLSend(SDK_HANDLE handle, const uint8_t *pBuffer, size_t SizeOfBuffer, size_t *sent_data);
OS_RETURN_VALS SDK_SSLReceive(SDK_HANDLE handle, void *pBuffer, const size_t SizeOfBuffer, size_t *recv_data);
OS_RETURN_VALS SDK_SSLDataAvailable(SDK_HANDLE handle, OS_TIMES timeout);
OS_RETURN_VALS SDK_SSLListen(SDK_HANDLE handle, int maxcon);
OS_RETURN_VALS SDK_SSLBind(SDK_HANDLE handle, SOCKET_ADDR *Address);
SDK_HANDLE SDK_SSLAccept(SDK_HANDLE handle, SOCKET_ADDR *Address);
SDK_HANDLE SDK_GetIpSocketHandle(SDK_HANDLE handle);
OS_RETURN_VALS SDK_LoadClientCertificate(SDK_HANDLE handle, const char *filename, int format);
OS_RETURN_VALS SDK_LoadClientPrivateKey(SDK_HANDLE handle, const char *filename, int format);
OS_RETURN_VALS SDK_LoadServerCertificate(SDK_HANDLE handle, const char *filename, int format);
OS_RETURN_VALS SDK_GetSSLConnectStatus (SDK_HANDLE handle, int *state);

/* Error codes for the SDL functions. */

/* Function codes. */
#define SSL_F_SDK_OpenSSLSocket				     100
#define SSL_F_SDK_CloseSSLSocket				 101
#define SSL_F_SDK_SSLConnect					 102
#define SSL_F_SDK_GetSSLBlockingMode			 103
#define SSL_F_SDK_SetSSLBlockingMode			 104
#define SSL_F_SDK_SetSSLMode				     105
#define SSL_F_SDK_SSLDisconnect				     106
#define SSL_F_SDK_SSLSend				         107
#define SSL_F_SDK_SSLReceive			         108
#define SSL_F_SDK_SSLDataAvailable			     109
#define SSL_F_SDK_SSLListen				         110
#define SSL_F_SDK_SSLBind				         111
#define SSL_F_SDK_SSLAccept				         112
#define SSL_F_SDK_GetIpSocketHandle			     113
#define SSL_F_SDK_LoadClientCertificate		     114
#define SSL_F_SDK_LoadClientPrivateKey		     115
#define SSL_F_SDK_LoadServerCertificate		     116

/* Reason codes. */
#define SSLSOCKETS_ORV_R_UNKNOWN_COMMAND				                         1
#define SSLSOCKETS_ORV_R_UNKNOWN_SUBCOMMAND				                         2
#define SSLSOCKETS_ORV_R_UNKNOWN_DEVICE_NUMBER				                 	 3
#define SSLSOCKETS_ORV_R_BUFFER_ADDRESS_ERROR			                         4
#define SSLSOCKETS_ORV_R_INTERRUPT_ADDRESS_ERROR			                     5
#define SSLSOCKETS_ORV_R_COMMAND_NOT_SUPPORTED				                     6
#define SSLSOCKETS_ORV_R_SUBCOMMAND_NOT_SUPPORTED			            	     7
#define SSLSOCKETS_ORV_R_MODE_NOT_SUPPORTED				                         8
#define SSLSOCKETS_ORV_R_CONFIGURATION_NOT_SET			                         9
#define SSLSOCKETS_ORV_R_CONFIGURATION_NOT_VALID			                     10
#define SSLSOCKETS_ORV_R_DEVICE_TIME_OUT				                         11
#define SSLSOCKETS_ORV_R_BUFFER_OVERFLOW				                         12
#define SSLSOCKETS_ORV_R_DEVICE_BUSY				                             13
#define SSLSOCKETS_ORV_R_DEVICE_NOT_AVAILABLE			                         15
#define SSLSOCKETS_ORV_R_DEVICE_FAULT		                                     16
#define SSLSOCKETS_ORV_R_DEVICE_NOT_OPEN		                                 17
#define SSLSOCKETS_ORV_R_DEVICE_REWOUND_DURING_IO		                         18
#define SSLSOCKETS_ORV_R_DEVICE_CONFIGURED_DURING_IO					         21
#define SSLSOCKETS_ORV_R_NO_TIMERS_AVAILBALE			                         22
#define SSLSOCKETS_ORV_R_TIMER_NOT_FOUND			                             23
#define SSLSOCKETS_ORV_R_INVALID_TIME_INTERVAL				                     24
#define SSLSOCKETS_ORV_R_PROCESS_IN_WRONG_STATE				                     25
#define SSLSOCKETS_ORV_R_PROCESS_NOT_FOUND				                         26
#define SSLSOCKETS_ORV_R_PARITY_ERROR_IN_DATA			                         27
#define SSLSOCKETS_ORV_R_LRC_ERROR_IN_DATA			                             28
#define SSLSOCKETS_ORV_R_DATA_OVERRUN				                             29
#define SSLSOCKETS_ORV_R_INVALID_DATA				                             30
#define SSLSOCKETS_ORV_R_INVALID_DEVICE_HANDLE			               	         31
#define SSLSOCKETS_ORV_R_INVALID_DATA_SIZE			                             32
#define SSLSOCKETS_ORV_R_NEGATIVE_ACKNOWLEDGE		                             33
#define SSLSOCKETS_ORV_R_FRAMING_ERROR		                                     34
#define SSLSOCKETS_ORV_R_NO_DIAL_LINE_AVAILABLE		                             35
#define SSLSOCKETS_ORV_R_XMODEM_1ST_BLOCK_ERROR_CRC			               		 38
#define SSLSOCKETS_ORV_R_XMODEM_1ST_BLOCK_ERROR_LRC			                     39
#define SSLSOCKETS_ORV_R_MODEM_RESPONSE_LINE_BUSY		                     	 40
#define SSLSOCKETS_ORV_R_MODEM_RESPONSE_NO_ANSWER		               		     41
#define SSLSOCKETS_ORV_R_PAPER_OUT				                                 42
#define SSLSOCKETS_ORV_R_OVER_HEAT				                                 43
#define SSLSOCKETS_ORV_R_DCD_LOST			                                     44
#define SSLSOCKETS_ORV_R_DM_RECEIVED			                                 45
#define SSLSOCKETS_ORV_R_SENDING_ERROR				                             46
#define SSLSOCKETS_ORV_R_UNEXPECTED_SNRM_RECEICED				                 47
#define SSLSOCKETS_ORV_R_LOSS_OF_POLLING				                         48
#define SSLSOCKETS_ORV_R_XMODEM_READ_TIMEOUT_MUST_BE_ERRDCD			             49
#define SSLSOCKETS_ORV_R_INVALID_LAPM_FRAME_RECEIVED		                     50
#define SSLSOCKETS_ORV_R_INVALID_LAPM_RECEIVE_SEQUENCE_NUMBER_RECEICED		     51
#define SSLSOCKETS_ORV_R_LAPM_RESPONSE_TIMEOUT_ERROR		                     52
#define SSLSOCKETS_ORV_R_LAPM_DISCONNECTED_MODE_FRAME_RECEIVED				     53
#define SSLSOCKETS_ORV_R_LAPM_DISCONNECT_FRAME_RECEIVED				             54
#define SSLSOCKETS_ORV_R_LAPM_FRAME_REJECT_FRAME_RECEIVED			             55
#define SSLSOCKETS_ORV_R_CARD_IS_ABSENT_IN_A_CARD_READER			             56
#define SSLSOCKETS_ORV_R_ERROR_FILE_SYSTEM_CORRUPTED_WAS_REFORMATTED			 57
#define SSLSOCKETS_ORV_R_ERROR_TOO_MANY_OPEN_FILE				                 58
#define SSLSOCKETS_ORV_R_ERROR_NO_SUCH_FILE				                         59
#define SSLSOCKETS_ORV_R_ERROR_ACCESS_DENIED			                         60
#define SSLSOCKETS_ORV_R_ERROR_MOMORY_ALLOCATION_ERROR		                     61
#define SSLSOCKETS_ORV_R_ERROR_GET_FIRST_MOST_BE_CALLED_BEFORE_GETNEXT		     62
#define SSLSOCKETS_ORV_R_ERROR_NO_MORE_FILE_IN_DIRECTORY		                 63
#define SSLSOCKETS_ORV_R_TWO_CARDS_DETECTED_BY_RTHE_CONTACTLESS_INTERFACE		 64
#define SSLSOCKETS_ORV_R_UNKNOWN_OS_ERROR_VALUE				                     65
#define SSLSOCKETS_ORV_R_MAXIMUM_NUMBER_OF_ERRORS			                     66


#ifdef  __cplusplus
}
#endif

#endif
